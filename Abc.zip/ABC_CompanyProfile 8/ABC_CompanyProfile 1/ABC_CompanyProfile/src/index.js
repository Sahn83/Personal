const express = require('express');
const app = express();
const path = require('path');
const exphbs = require('express-handlebars');
const collection = require('./mongo');

// Paths
const imagesPath = path.join(__dirname, '../images');
const templatePath = path.join(__dirname, '../templates');
const publicPath = path.join(__dirname, '../public');

const session = require('express-session');
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));

// Configure Handlebars as the template engine
// app.engine(
//   'hbs',
//   exphbs({
//     extname: '.hbs',
//     defaultLayout: 'main',
//     // Specify the default layout file
//     layoutsDir: path.join(__dirname, 'views/layouts'),
//     partialsDir: path.join(templatePath, 'partials')
//   })
// );

app.set('view engine', 'hbs');
app.use(express.static(publicPath));
app.use(express.static(imagesPath));
app.use(express.json());
app.set('views', templatePath);
app.use(express.urlencoded({ extended: false }));

app.get('/', (req, res) => {
    res.render('login');
});

//next page
app.get('/templates/next', (req, res) => {
    res.render('next'); // Assuming your template engine is set up to render 'next.hbs'
});

app.get('/next', (req, res) => {
    res.redirect('/templates/next');
});

//hina page
app.get('/templates/hina', (req, res) => {
    res.render('hina'); // Assuming your template engine is set up to render 'hina.hbs'
});

app.get('/hina', (req, res) => {
    res.redirect('/templates/hina');
});

//abhishek page
app.get('/templates/abhishek', (req, res) => {
    res.render('abhishek'); // Assuming your template engine is set up to render 'abhishek.hbs'
});

app.get('/abhishek', (req, res) => {
    res.redirect('/templates/abhishek');
});


//sahnwaz page
app.get('/templates/sahnwaz', (req, res) => {
    res.render('sahnwaz'); // Assuming your template engine is set up to render 'abhishek.hbs'
});

app.get('/sahnwaz', (req, res) => {
    res.redirect('/templates/sahnwaz');
});

//indranil page
app.get('/templates/indranil', (req, res) => {
    res.render('indranil'); // Assuming your template engine is set up to render 'abhishek.hbs'
});

app.get('/indranil', (req, res) => {
    res.redirect('/templates/indranil');
});
//////////////////  
app.get('/signup', (req, res) => {
    res.render('signup');
});

app.post('/signup', async (req, res) => {
    const data = {
        name: req.body.name,
        password: req.body.password
    };

    await collection.insertMany([data]);
    res.render('login');
});

app.post('/login', async (req, res) => {
    try {
        const check = await collection.findOne({ name: req.body.name });

        if (check.password === req.body.password) {
            res.status(201).render('index');
            // , { naming: `${req.body.password}+${req.body.name}` }
        } else {
            res.send('Incorrect password');
        }
    } catch (e) {
        res.send('Wrong details');
    }
});

app.post('/logout', (req, res) => {
    // Destroy the user session
    req.session.destroy((err) => {
        if (err) {
            console.error('Error destroying session:', err);
        } else {
            res.redirect('/'); // Redirect to the home page after logout
        }
    });
});

app.listen(3000, () => {
    console.log('Port connected');
});
