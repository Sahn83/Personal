// Replace 'YOUR_API_KEY' and 'YOUR_API_ENDPOINT' with your actual API key and endpoint
const apiKey = 'ek9DJ4TyMZcywa3KDmv5hFWJuOcw96GBdxtZhhGwpRK7zMX2';
const apiEndpoint = 'https://ai-foundation-api.app/ai-foundation/chat-ai/gpt4';

function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    const chatBox = document.getElementById('chat-box');

    // Display user message in the chat box
    appendMessage('user', userInput);
    
    // Make a request to the ChatAI API
    makeApiRequest(userInput)
        .then(response => {
            const assistantResponse = response.choices[0].message.content;
            // Display assistant's response in the chat box
            appendMessage('assistant', assistantResponse);
        })
        .catch(error => {
            console.error('Error:', error);
            appendMessage('assistant', 'Oops! An error occurred.');
        });
        document.getElementById("user-input").value = '';
}

function makeApiRequest(userMessage) {
    const apiUrl = apiEndpoint;

    const requestData = {
        messages: [{ role: 'user', content: userMessage }],
    };

    return fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'api-key': apiKey,
        },
        body: JSON.stringify(requestData),
    })
    .then(response => response.json());
}

function appendMessage(role, content) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.className =  'content ' + role + '-content';
    messageElement.textContent = role.charAt(0).toUpperCase() + role.slice(1) + ': ' + content;
    chatBox.appendChild(messageElement);
    // Scroll to the bottom of the chat box
    chatBox.scrollTop = chatBox.scrollHeight;
}

function openForm() {
    document.getElementById("myForm").style.display = "block";
    document.getElementById("user-input").value = '';
  }
  
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
    document.getElementById("chat-box").innerHTML = '';    
  }
  function clearForm() {
     document.getElementById("user-input").value = '';
     document.getElementById("chat-box").innerHTML = '';
 }